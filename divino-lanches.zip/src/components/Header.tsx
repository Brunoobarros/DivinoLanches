import React from 'react';
import { motion } from 'motion/react';
import { Crown, Clock } from 'lucide-react';

export default function Header() {
  return (
    <header className="relative bg-brand-red text-white overflow-hidden shadow-md border-b-4 border-brand-amber">
      {/* Subtle brand patterns / ambient highlights */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 left-10 w-96 h-20 bg-brand-amber/15 rotate-6 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 py-4 md:py-5 flex flex-col sm:flex-row items-center justify-between gap-4 relative z-10">
        {/* Logo and Brand Name matching the uploaded artwork 1:1 */}
        <div className="flex flex-row items-center gap-4 text-left">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 180, damping: 15 }}
            className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-md relative group shrink-0"
          >
            {/* Crown placed beautifully above and slightly left-titled over the letter D just like the art */}
            <div className="relative flex items-center justify-center w-full h-full">
              <Crown className="w-6 h-6 text-brand-amber fill-brand-amber absolute -top-2.5 -left-1.5 rotate-[-15deg] drop-shadow-xs" />
              <span className="text-2xl font-black font-display text-brand-red pt-0.5">D</span>
            </div>
          </motion.div>

          <div className="flex flex-col">
            <div className="flex flex-col">
              <h1 className="text-2xl md:text-3xl font-black tracking-tight font-display text-white uppercase leading-none">
                DIVINO
              </h1>
              <span className="text-[10px] font-bold tracking-[0.3em] text-brand-amber uppercase font-sans mt-0.5">
                LANCHES
              </span>
            </div>
            <p className="text-red-150 text-[11px] mt-1 font-sans leading-relaxed max-w-xs opacity-90 hidden md:block">
              O autêntico sabor artesanal feito com excelência.
            </p>
          </div>
        </div>

        {/* Info badges */}
        <div className="flex flex-wrap justify-center sm:justify-end gap-2.5 text-sm">
          <div className="flex items-center gap-2 bg-black/15 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-white/10">
            <Clock className="w-3.5 h-3.5 text-brand-amber" />
            <div>
              <p className="text-[9px] text-red-200 font-bold uppercase tracking-wider">Funcionamento</p>
              <p className="font-bold text-xs text-white font-mono">18:00 às 23:30</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-emerald-600 text-white px-3 py-1.5 rounded-xl shadow-xs border border-emerald-500/30 font-sans font-bold text-xs uppercase tracking-wider">
            <span className="w-1.5 h-1.5 bg-white rounded-full block animate-ping" />
            <span className="text-[10px]">Aberto</span>
          </div>
        </div>
      </div>
    </header>
  );
}
